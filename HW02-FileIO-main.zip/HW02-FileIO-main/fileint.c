/* PLEASE EDIT THIS FILE */

#include "fileint.h"

#include <stdbool.h>
#include <stdio.h>

bool addFile(char *filename, int *sum) {
  /* BEGIN STUDENT ANSWER */

  // complete as described in the README

  /* END STUDENT ANSWER */
  return true;
}

bool writeSum(char *filename, int sum) {
  /* BEGIN STUDENT ANSWER */

  // complete as described in the README

  /* END STUDENT ANSWER */
  return true;
}
